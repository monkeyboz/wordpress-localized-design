console.log( 'Admin Page Framework Demo: ' + my_script.a );
console.log( 'Admin Page Framework Demo: ' + my_script.style_handle_id );